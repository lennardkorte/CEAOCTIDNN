# -*- coding: utf-8 -*-
"""
Created on Tue Apr 12 15:16:36 2021

@author: Robin

Models for training
"""

import torch
import torch.nn as nn
from torchvision import models
from efficientnet_pytorch import EfficientNet
import pretrainedmodels
import torch.nn.functional as F
import math
import pytorch.common.resnet_custom as resnet_custom
from typing import Type, Tuple, Union

"""---------------------AlexNet ------------"""


class AlexNet(nn.Module):

    def __init__(self, cfg):
        super(AlexNet, self).__init__()
        pretrained = cfg.get('pretrained', True)
        self.output_size = cfg['numOut']
        # self.layer1 = nn.Linear(1000,1)
        self.net = models.alexnet(pretrained)
        # for p in self.net.parameters():
        #   p.requires_grad=False
        self.net.classifier = nn.Sequential(
            nn.Dropout(),
            nn.Linear(256 * 6 * 6, 4096),
            nn.ReLU(inplace=True),
            nn.Dropout(),
            nn.Linear(4096, 4096),
            nn.ReLU(inplace=True),
            nn.Linear(4096, self.output_size),
        )

    def forward(self, x):
        return self.net(x)


"""---------------------resnet18 ------------"""


class ResNet18(nn.Module):

    def __init__(self, cfg):  # adjustedpool = False,
        super(ResNet18, self).__init__()
        pretrained = cfg.get('pretrained', True)
        self.output_size = cfg['numOut']
        # self.layer1 = nn.Linear(1000,1)
        self.net = models.resnet18(pretrained)
        # self.net.conv1 = nn.Conv2d(1, 64, kernel_size=7, stride=2, padding=3, bias=False)
        self.net.avgpool = nn.AdaptiveAvgPool2d(1)
        # =============================================================================
        #         if self.adjusted == True:
        #             self.net.avgpool = nn.AvgPool2d(kernel_size=16, stride=1, padding=0)
        # =============================================================================
        self.net.fc = nn.Linear(512, self.output_size)

    def forward(self, x):
        return self.net(x)


"""---------------------WideResNet50 ------------"""


class WideResNet50(nn.Module):

    def __init__(self, cfg):  # adjustedpool = False,
        super(WideResNet50, self).__init__()
        pretrained = cfg.get('pretrained', True)
        self.output_size = cfg['numOut']
        # self.layer1 = nn.Linear(1000,1)
        self.net = models.wide_resnet50_2(pretrained)
        # self.net.conv1 = nn.Conv2d(1, 64, kernel_size=7, stride=2, padding=3, bias=False)
        self.net.avgpool = nn.AdaptiveAvgPool2d(1)
        # =============================================================================
        #         if self.adjusted == True:
        #             self.net.avgpool = nn.AvgPool2d(kernel_size=16, stride=1, padding=0)
        # =============================================================================
        self.net.fc = nn.Linear(2048, self.output_size)

    def forward(self, x):
        return self.net(x)


"""---------------------ResNext50 ------------"""


class ResNext50(nn.Module):

    def __init__(self, cfg):  # adjustedpool = False,
        super(ResNext50, self).__init__()
        pretrained = cfg.get('pretrained', True)
        self.output_size = cfg['numOut']
        # self.layer1 = nn.Linear(1000,1)
        self.net = models.resnext50_32x4d(pretrained)
        # self.net.conv1 = nn.Conv2d(1, 64, kernel_size=7, stride=2, padding=3, bias=False)
        self.net.avgpool = nn.AdaptiveAvgPool2d(1)
        # =============================================================================
        #         if self.adjusted == True:
        #             self.net.avgpool = nn.AvgPool2d(kernel_size=16, stride=1, padding=0)
        # =============================================================================
        self.net.fc = nn.Linear(2048, self.output_size)

    def forward(self, x):
        return self.net(x)


"""---------------Densenet 121 -----------------"""


class DenseNet121(nn.Module):

    def __init__(self, cfg):
        super(DenseNet121, self).__init__()
        pretrained = cfg.get('pretrained', True)
        self.output_size = cfg['numOut']
        self.net = models.densenet121(pretrained)
        self.net.classifier = nn.Linear(1024, self.output_size)

    def forward(self, x):
        return self.net(x)


class EfficientNetB6(nn.Module):

    def __init__(self, cfg):
        super(EfficientNetB6, self).__init__()
        pretrained = cfg.get('pretrained', True)
        self.output_size = cfg['numOut']
        if pretrained:
            self.net = EfficientNet.from_pretrained('efficientnet-b6')
        else:
            self.net = EfficientNet.from_name('efficientnet-b6')
        self.net._fc = nn.Linear(2304, self.output_size)

    def forward(self, x):
        return self.net(x)


class SENet(nn.Module):

    def __init__(self, cfg):
        super(SENet, self).__init__()
        pretrained = cfg.get('pretrained', True)
        self.output_size = cfg['numOut']
        if pretrained:
            self.net = pretrainedmodels.__dict__['se_resnext50_32x4d'](pretrained='imagenet')  # 'se_resnext50_32x4d'
        else:
            self.net = pretrainedmodels.__dict__['se_resnext50_32x4d'](pretrained=None)  # 'se_resnext50_32x4d'
        self.net.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.net.last_linear = nn.Linear(2048, self.output_size)

    def forward(self, x):
        #        x = F.relu(self.net(x))
        #        x = self.fc(x)
        return self.net(x)


# ##################
# #### GET MODEL ###
# ##################

model_map = {'ResNet18': ResNet18,
             'ResNext50': ResNext50,
             'WideResNet50': WideResNet50,
             'AlexNet': AlexNet,
             'SENet': SENet,
             'EfficientNetB6': EfficientNetB6,
             'DenseNet121': DenseNet121
             }


def get_model(cfg):
    if cfg['model_type'] not in model_map:
        raise ValueError('Name of model "{0}" unknown.'.format(cfg['model_type']))
    else:
        model = model_map[cfg['model_type']](cfg)
    return model

# ########################
# ### Helper functions ###
# ########################


def count_parameters(model):
    return sum(p.numel() for p in model.parameters())


def count_trainable(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


def get_trainable(model_params):
    return (p for p in model_params if p.requires_grad)


def get_frozen(model_params):
    return (p for p in model_params if not p.requires_grad)


def all_trainable(model_params):
    return all(p.requires_grad for p in model_params)


def all_frozen(model_params):
    return all(not p.requires_grad for p in model_params)


def freeze_all(model_params):
    for param in model_params:
        param.requires_grad = False
