# -*- coding: utf-8 -*-
import torch
import torch.nn as nn
import torch.optim as optim
# from torch.optim import lr_scheduler
# import torch.nn.functional as F
# import torchvision
# from torchvision import datasets, models as tv_models
# from torch.utils.data import DataLoader
# from torchsummary import summary
# from scipy import io
# import threading
# import math
# import gc
# import copy
# import psutil
# import visdom
# import sklearn.preprocessing
# from sklearn.utils import class_weight
# from sklearn.metrics import confusion_matrix, auc, roc_curve, f1_score, roc_auc_score
import numpy as np
import pickle
from pathlib import Path
import os
import sys
from glob import glob
import re
import importlib
import time
import wandb
import scipy.io as sio
import random
import IVOCT.models as models
import IVOCT.utils as utils
import IVOCT.data_loaders as data_loaders


def main():
    # add configuration file
    # Dictionary for model configuration
    cfg = {}
    # torch.backends.cudnn.enabled = False
    torch.backends.cudnn.benchmark = True


    # if len(sys.argv) > 5:
    #     if sys.argv[5] == 'all':
    #         split_name_list = ['standard_split', 'turkey_split', 'liver_split']
    #     else:
    #         split_name_list = [str(sys.argv[5])]
    # else:
    #     split_name_list = [str(sys.argv[2])]
    #
    # for split_name in split_name_list:

    cfg = {}
    # Import machine config
    pc_cfg = importlib.import_module('IVOCT.pc_cfgs.' + sys.argv[1])
    cfg.update(pc_cfg.cfg)

    # Import model config
    print(cfg['base_path'])
    model_cfg = importlib.import_module('IVOCT.cfgs.' + sys.argv[2])
    cfg_model = model_cfg.init(cfg)
    cfg.update(cfg_model)

    # import / update data split cfg
    if len(sys.argv) > 5:
        print('Update the data split')
        split_name = str(sys.argv[5])
        # model_cfg = importlib.import_module('cfgs.'+ sys.argv[5])
        model_cfg = importlib.import_module('Force4D.cfgs.' + split_name)
        cfg_data = model_cfg.init(cfg)
        cfg.update(cfg_data)
    else:
        split_name = ''

    if len(sys.argv) > 1:
        # Set visible devices
        if 'gpu' in sys.argv[3]:
            cfg['numGPUs'] = [int(s) for s in re.findall(r'\d+', sys.argv[3])]
            cuda_str = ""
            for i in range(len(cfg['numGPUs'])):
                cuda_str = cuda_str + str(cfg['numGPUs'][i])
                if i is not len(cfg['numGPUs']) - 1:
                    cuda_str = cuda_str + ","
            print("Devices to use:", cuda_str)
            os.environ["CUDA_VISIBLE_DEVICES"] = cuda_str

        # use deterministic training?
    if cfg.get('determ_train', False):
        torch.manual_seed(18)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        if cfg.get('determ_batching', False):
            np.random.seed(18)
            random.seed(18)

    # Indicate training
    # cfg['trainSetState'] = 'train'  # not used

    # Save dictonary
    saveDict = {}  # dictonary for the final test result

    # Create basepath if it doesnt exist yet
    cfg['Save_Name'] = str(sys.argv[2]) + '_' + str(sys.argv[4])
    cfg['save_path'] = cfg['save_path'] + cfg['experiment_folder'] + cfg['Save_Name']
    cfg['save_path'] = cfg['save_path'] + '/'

    # Set configs for HPC usage
    if 'hpc_local' in sys.argv[1]:
        print('Preloading is used for HPC Cluster')
        cfg['preload'] = False
        # cfg['batchSize_eval'] = 150
    else:
        print('Use MTEC Cluster')
        # cfg['preload'] = False

    # Take care of CV
    for cv in range(cfg['numCV']):
        # check if Crossfold is already partly trained
        load_old = 0
        path_last = Path(cfg['save_path'] + cfg['Save_Name'] + '_CV_end' + str(cv) + '.pkl')
        prevFile = Path(cfg['save_path'] + cfg['Save_Name'] + '_CV_' + str(cv) + '.pkl')
        if path_last.exists():
            print("CV already Trained")
            # with open(cfg['save_path'] + cfg['Save_Name'] + '_CV_end_save' + str(cv) +'.pkl', 'rb') as f:
            #    saveDict = pickle.load(f)  # load save dict

        elif prevFile.exists():
            print("Only Part of CV already done")
            # load_old = 1
            # with open(path_last, 'rb') as f:
            #     cfg = pickle.load(f) # load cfg
            # cfg['preload'] = False

        print('Start Evaluation')
        cfg['saveDir'] = cfg['save_path'] + 'cv_' + str(cv)
        # Init wandb project for current fold (cv)
        wandb.init(project="IVOCT", group=str(sys.argv[2]) + '_' + str(sys.argv[4]) + '_' + split_name,
                   name=str(sys.argv[2]) + '_' + str(sys.argv[4]) + '_' + str(cv), reinit=True,
                   dir=os.getenv("WANDB_DIR", '/tmp/Mieling/'))

        # Reduce for Weights and biases
        model_params = utils.wandb_reduce_dict(cfg, cv)
        wandb.config.update(model_params)  # update the wandb config

        # Collect model variables
        modelVars = {}
        modelVars['device'] = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        print(modelVars['device'])
        # Scaler for mixep precision training
        modelVars['scaler'] = torch.cuda.amp.GradScaler()
        # get data loaders
        cfg, modelVars = data_loaders.return_ivoct_data_loaders(cfg, modelVars, cv)

        # Models
        modelVars['model'] = models.get_model(cfg)

        # multi gpu support
        if len(cfg['numGPUs']) > 1:
            modelVars['model'] = nn.DataParallel(modelVars['model'])
        modelVars['model'] = modelVars['model'].to(modelVars['device'])

        # Loss
        if cfg.get('Loss_Function', 'MSE') == 'MSE':
            modelVars['criterion'] = nn.MSELoss()
        elif cfg.get('Loss_Function', 'MSE') == 'SmoothL1Loss':
            modelVars['criterion'] = nn.SmoothL1Loss()
        elif cfg.get('Loss_Function', 'MSE') == 'cross_entropy':
            modelVars['criterion'] = nn.CrossEntropyLoss()
        else:
            modelVars['criterion'] = nn.L1Loss()

        pytorch_total_params = sum(p.numel() for p in modelVars['model'].parameters() if p.requires_grad)
        print('Number of Training Parameters', pytorch_total_params)

        if cfg.get('optimizer', 'Adam') == 'Adam':
            modelVars['optimizer'] = optim.Adam(modelVars['model'].parameters(), lr=cfg['learning_rate'])
        elif cfg.get('optimizer', 'Adam') == 'AdamW':
            modelVars['optimizer'] = optim.AdamW(modelVars['model'].parameters(), lr=cfg['learning_rate'])
        elif cfg.get('optimizer', 'Adam') == 'SGD':
            modelVars['optimizer'] = optim.SGD(modelVars['model'].parameters(), lr=cfg['learning_rate'], momentum=0.9)

        # Evalute on Test-Set with Last Model
        if cfg.get('use_test_set', False):

            # restore last model
            model_paths = glob(cfg['saveDir'] + '/*.pt')
            print(model_paths)
            assert len(model_paths) < 3, "More than two models in path"
            model_found = False
            # Find last, not last best checkpoint
            for mdl_path in model_paths:
                if 'best' not in mdl_path:
                    model_found = True
                    last_mdl_path = mdl_path

            if model_found:
                print("Restoring last Model: ", last_mdl_path)  # restore last Model
                # Load
                state = torch.load(last_mdl_path)  # load previous model with states

                state = utils.remove_module_from_state(state)  # remove modules from state

                if isinstance(modelVars['model'], nn.DataParallel):
                    modelVars['model'].module.load_state_dict(state['state_dict'])
                else:
                    modelVars['model'].load_state_dict(state['state_dict'])

                modelVars['model'].eval()

                print('Check with Last Model on Test-Set:')
                loss_test_last, metrics_test_last, predictions_test_last, targets_test_last = utils.get_classification_eval(
                    cfg, 'testInd', modelVars)
                print('Loss:', loss_test_last)
                print('Metrics Accuracy: ', metrics_test_last[0])

                cfg['all_metrics_test_last'] = metrics_test_last
                cfg['all_loss_test_set_last'] = loss_test_last
                cfg['predictions_test_last'] = predictions_test_last  # Predictions
                cfg['targets_test_last'] = targets_test_last  # store to have everything in one file

                wandb.log({'Test Accuracy (Last)': metrics_test_last[0]})
                wandb.log({'Test sensitivity (Last)': metrics_test_last[1]})
                wandb.log({'Test specificity (Last)': metrics_test_last[2]})
                wandb.log({'Test F1 (Last)': metrics_test_last[4]})

            print('Check with Best Model based on Val set - Test-Set:')
            model_paths = glob(cfg['saveDir'] + '/*.pt')
            best_model_found = False
            for mdl_path in model_paths:
                if 'best' in mdl_path:
                    best_model_found = True
                    print("Restoring best Model: ", mdl_path)  # restore best Model based on Validation Set
                    # Load
                    state = torch.load(mdl_path)  # load previous model with states
                    # modelVars['model'].load_state_dict(state['state_dict'])
                    # Initialize model and optimizer
                    state = utils.remove_module_from_state(state)  # remove modules from state
                    # Initialize model and optimizer
                    if isinstance(modelVars['model'], nn.DataParallel):
                        modelVars['model'].module.load_state_dict(state['state_dict'])
                    else:
                        modelVars['model'].load_state_dict(state['state_dict'])

                    loss_test_best, metrics_test_best, predictions_test_best, targets_test_best \
                        = utils.get_classification_eval(cfg, 'testInd', modelVars)
                    break

            if not best_model_found:
                print('No Best Model during Training (Take Last Model Instead)')
                loss_test_best = loss_test_last
                metrics_test_best = metrics_test_last
                predictions_test_best = predictions_test_last
                targets_test_best = targets_test_last


            print("Metrics on Testset (Best Val Model) {}".format(metrics_test_best))
            print('-------------------------------------------')
            cfg['predictions_test_best'] = predictions_test_best
            cfg['targets_test_best'] = targets_test_best
            cfg['all_metrics_test_best'] = metrics_test_best
            cfg['all_loss_test_set_best'] = loss_test_best

            wandb.log({'Test Accuracy (Best)': metrics_test_best[0]})
            wandb.log({'Test sensitivity (Best)': metrics_test_best[1]})
            wandb.log({'Test specificity (Best)': metrics_test_best[2]})
            wandb.log({'Test F1 (Best)': metrics_test_best[4]})

        if cv == 0:
            saveDict['targets_all'] = cfg['targets_test_best']
            saveDict['predictions_all'] = cfg['predictions_test_best']
        else:
            saveDict['targets_all'] = np.concatenate((saveDict['targets_all'], np.array(cfg['targets_test_best'])))
            saveDict['predictions_all'] = np.concatenate(
                (saveDict['predictions_all'], np.array(cfg['predictions_test_best'])))

        # Save Setting for current Fold
        with open(cfg['save_path'] + cfg['Save_Name'] + "_CV_end_eval_" + split_name + str(cv) + '.pkl',
                  'wb') as f:
            pickle.dump(cfg, f, pickle.HIGHEST_PROTOCOL)
            # Save Final cfg
        # sio.savemat(cfg['save_path']  + cfg['Save_Name']+ "_CV_"+ str(cv) +".mat",cfg)
        # Save Targets and Predictions
        with open(cfg['save_path'] + cfg['Save_Name'] + "_CV_end_save_eval_" + split_name + str(cv) + '.pkl',
                  'wb') as f:
            pickle.dump(saveDict, f, pickle.HIGHEST_PROTOCOL)
            # sio.savemat(cfg['save_path']  + cfg['Save_Name']+ "_all_folds_predictions" +".mat", saveDict)  # stack and save predictions for the trained folds

        if cv == cfg['numCV'] - 1:
            print('Training is done......')
            # sio.savemat(cfg['save_path']  + cfg['Save_Name']+ "_all_folds" +".mat", saveDict)
            with open(cfg['save_path'] + cfg['Save_Name'] + '_all_folds_eval_' + split_name + '.pkl',
                      'wb') as f:
                pickle.dump(saveDict, f, pickle.HIGHEST_PROTOCOL)
            print('Final Logging file saved!')
        else:
            print('Next Fold......')
            # Free everything in modelvars
            modelVars.clear()

        # Free everything in modelvars
        modelVars.clear()


if __name__ == '__main__':
    main()
