# -*- coding: utf-8 -*-
# import matplotlib.pyplot as plt
# import os
import torch
import numpy as np
from torch.utils.data import Dataset, DataLoader
from copy import deepcopy
import h5py
import time
import warnings
from collections import OrderedDict
# import torchio as tio
# from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error, confusion_matrix, f1_score, auc, roc_curve
from scipy.stats.stats import pearsonr
import math


class IVOCT_Dataset(Dataset):
    """IVOCT dataset. Cross section images labeled with plaque by experts

    Labels are associated with:
    'Calcified Plaque': 1
    'Plaque with lipid depot': 2
    'Fibrous Plaque': 3
    'Calcif./Fibr. Plaque': 4
    'Lipid/Fibr. Plaque': 5
    'No Plaque visible': 6

    """

    def __init__(self, cfg, indSet):
        """
        Args:
            cfg (dict): Configuration for loading
            indSet (string): Indicates train, val, test
        """
        self.numOut = cfg['numOut']  # number output network
        # Indices /  Current indSet = 'trainInd'/'valInd'/'testInd'
        self.indices = cfg[indSet]
        self.indSet = indSet
        self.data_path = cfg['all_files_path']
        self.datasets = [h5py.File(path, 'r')[cfg['dataset_name']] for path in self.data_path]
        self.label_data = cfg['data_labels']
        # Define data augmentation
        # self.data_augmetation = cfg.get('data_augmetation', False)
        # self.trans = transforms.ToTensor()
        # preload to memory
        self.preload = cfg.get('preload', False)
        # pad images with zeros to 3 channels
        self.padding = cfg.get('padding', True)
        # data normalization
        self.mean_std_normalize = cfg.get('mean_std_normalize', False)
        self.zero_one_normalize = cfg.get('zero_one_normalize', False)

        # Preload
        # if self.indSet != 'trainInd':
        if self.preload:
            start_time_preload = time.time()
            self.input_data = {}
            print('Pre-Load Data')
            for p, dset in enumerate(self.datasets):
                self.input_data[p] = np.squeeze(dset[:])  # squeeze redundant
                if p % 200 == 0:
                    print("Data Loaded:", p, "/", len(self.datasets), '- Preload Duration: ',
                          time.time() - start_time_preload, end="\r")

        print('Length of Set', indSet, len(self.indices))
        self.length = len(self.indices)

    def __len__(self):
        return self.length

    def normalize_input(self, data):
        if self.mean_std_normalize:
            mean_vol = np.mean(data)
            std_vol = np.std(data)
            data = (data - mean_vol) / (std_vol + 0.0001)
        elif self.zero_one_normalize:
            min_vol = np.min(data)
            max_vol = np.max(data)
            data = (data - min_vol) / (max_vol - min_vol)
        return data

    # def normalize_label(self, label):
    #     # Normalize Labels
    #     if self.label_normalization:
    #         for j in range(label.shape[0]):
    #             label[j] = (label[j] - (self.Min_Data_Scale[j])) / (self.Max_Data_Scale[j] - (self.Min_Data_Scale[j]))
    #     elif self.label_standardization:
    #         for j in range(label.shape[0]):
    #             label[j] = (label[j] - (self.Min_Data_Scale[j])) / (
    #                 self.Max_Data_Scale[j])  # here min is the mean; and max is the std.
    #     return label

    def get_forecasting_labels(self, trajectory_point, start_point, reverse, base_path):
        # forecasting labels pos_f_t
        pos_f_t = np.zeros((self.prediction_horizion, 3))

        for f_t in range(0, self.prediction_horizion):
            if reverse == False:
                trajectory_point_predict = trajectory_point + f_t + 1
            else:
                trajectory_point_predict = trajectory_point - f_t - 1

                # get the path
            new_point = base_path + '/' + str(trajectory_point_predict) + '.h5'
            with h5py.File(new_point, 'r') as f:
                label_f = np.squeeze(np.transpose(f['label'][()]))
            pos_f_t[f_t, :] = label_f - start_point

        return pos_f_t

    def __getitem__(self, idx):
        # index of current sample
        elem_idx = int(self.indices[idx])

        # ############################# Get the Input Data ###########################################
        if self.preload:
            data = self.input_data[elem_idx]
        else:
            data = self.datasets[elem_idx][:]
        label = self.label_data[elem_idx]

        # if self.data_augmetation:
        #     # Only apply during Training?
        #     if self.indSet == 'trainInd':
        #         do something
        # Apply data normalization
        data = self.normalize_input(data)
        # add channel dimension
        data = np.expand_dims(data, 0)
        # create padding for pretrained models with 3 channel input
        if self.padding:
            data = np.concatenate((data, np.zeros((2, *data.shape[1:]))), axis=0)
        # cast to float32
        label = label.astype(np.float32)
        data = data.astype(np.float32)
        # data: c,h,w (2D)
        # label: class
        return data, label  #, idx


def remove_module_from_state(state):
    # helper function to remove module string from state checkpoint
    new_state_dict = OrderedDict()
    for k, v in state['state_dict'].items():
        # print(k)
        name = k.replace("module.", "")  # remove 'module.' of dataparallel
        # print(name)
        new_state_dict[name] = v
    state['state_dict'] = new_state_dict
    return state


def zero_pad_image(image, padding):
    # 3D case with temporal dimension
    if len(image.shape) > 2:
        # image with padding
        image_pad = np.zeros((image.shape[0], image.shape[1] + 2 * padding, image.shape[2] + 2 * padding))
        # now insert the image
        image_pad[:, padding:image.shape[1] + padding, padding:image.shape[2] + padding] = image
    # 2D case without temporal dimension
    else:
        # image with padding
        image_pad = np.zeros((image.shape[0] + 2 * padding, image.shape[1] + 2 * padding))
        # now insert the image
        image_pad[padding:image.shape[0] + padding, padding:image.shape[1] + padding] = image

    return image_pad


def get_classification_eval(cfg, ind, modelVars):
    print('---------------------------------')
    print('Set: ', ind)
    # Set up variables
    loss_all_set = []
    predictions_set = []
    targets_set = []
    num_classes = cfg['numOut']
    # start_it_e = time.time()
    for i, (inputs, labels) in enumerate(modelVars['dataloader_' + ind]):

        inputs = inputs.to(modelVars['device'])
        labels = labels.squeeze().type(torch.LongTensor).to(modelVars['device'])

        with torch.set_grad_enabled(False):
            with torch.cuda.amp.autocast():
                outputs = modelVars['model'](inputs)
                loss = modelVars['criterion'](outputs, labels)

        if i == 0:
            loss_all_set = loss.unsqueeze(0)
            predictions_set = outputs
            targets_set = labels
        else:
            loss_all_set = torch.cat([loss_all_set, loss.unsqueeze(0)], 0)  # input (t*batch, cxbxwxh)
            predictions_set = torch.cat([predictions_set, outputs], 0)
            targets_set = torch.cat([targets_set, labels], 0)

    targets_one_hot = np.array(torch.nn.functional.one_hot(targets_set, cfg['numOut']).cpu().numpy())
    # To numpy arrays
    predictions = np.array(predictions_set.cpu().numpy())
    targets = np.array(targets_set.cpu().numpy())
    mean_loss = np.mean(np.array(loss_all_set.cpu().numpy()))

    # Calculate metrics
    warnings.warn("Did not double check if all of these metrics are calculated correctly")
    # Accuarcy
    acc = np.mean(np.equal(np.argmax(predictions, 1), targets))
    # Confusion matrix
    conf = confusion_matrix(targets, np.argmax(predictions, 1))
    # print("Conf",conf)
    # Class weighted accuracy
    wacc = conf.diagonal() / conf.sum(axis=1)
    # Sensitivity / Specificity
    sensitivity = np.zeros([num_classes])
    specificity = np.zeros([num_classes])
    if num_classes > 2:
        # will currently result in error if not all classes are in test set...
        if conf.shape[0] == num_classes:
            for k in range(num_classes):
                sensitivity[k] = conf[k, k] / (np.sum(conf[k, :]))
                true_negative = np.delete(conf, [k], 0)
                true_negative = np.delete(true_negative, [k], 1)
                true_negative = np.sum(true_negative)
                false_positive = np.delete(conf, [k], 0)
                false_positive = np.sum(false_positive[:, k])
                specificity[k] = true_negative / (true_negative + false_positive)
        else:
            tn, fp, fn, tp = confusion_matrix(targets, np.argmax(predictions, 1)).ravel()
            sensitivity = tp / (tp + fn)
            specificity = tn / (tn + fp)
        # F1 score
        f1 = f1_score(targets, np.argmax(predictions, 1), average='weighted')
    else:
        tn, fp, fn, tp = confusion_matrix(targets, np.argmax(predictions, 1)).ravel()
        sensitivity = tp / (tp + fn)
        specificity = tn / (tn + fp)
        # F1 score
        f1 = f1_score(targets, np.argmax(predictions, 1))
    # AUC
    fpr = {}
    tpr = {}
    roc_auc = np.zeros([num_classes])
    for i in range(num_classes):
        fpr[i], tpr[i], _ = roc_curve(targets_one_hot[:, i], predictions[:, i])
        roc_auc[i] = auc(fpr[i], tpr[i])

    metrics = [acc, sensitivity, specificity, conf, f1, roc_auc, wacc]

    return mean_loss, metrics, predictions, targets


def wandb_reduce_dict(cfg, cv):
    model_params = deepcopy(cfg)

    del model_params['numGPUs']
    del model_params['trainInd']
    del model_params['valInd']
    del model_params['testInd']
    # del model_params['train/Ind_eval']

    del model_params['trainIndCV']
    del model_params['valIndCV']
    del model_params['testIndCV']
    del model_params['trainInd_evalCV']

    model_params.pop('val_best', None)
    model_params.pop('last_best_ind', None)
    model_params.pop('ES_counter', None)
    model_params.pop('lastlast_ind', None)

    if 'testSet' in model_params:
        del model_params['testSet']
    if 'valSet' in model_params:
        del model_params['valSet']
    if 'train_evalSet' in model_params:
        del model_params['train_evalSet']
    if 'trainSet' in model_params:
        del model_params['trainSet']
    if 'val_test_Set' in model_params:
        del model_params['val_test_Set']

    del model_params['all_files_path']
    del model_params['data_paths']
    # del model_params['data_labels']

    if 'testSetCV' in model_params:
        del model_params['testSetCV']
    if 'valSetCV' in model_params:
        del model_params['valSetCV']
    if 'train_evalSetCV' in model_params:
        del model_params['train_evalSetCV']
    if 'trainSetCV' in model_params:
        del model_params['trainSetCV']

    # if cv!=0:
    if 'predictions_test_best' in model_params:
        del model_params['predictions_test_best']
    if 'targets_test_best' in model_params:
        del model_params['targets_test_best']
    if 'predictions_test_last' in model_params:
        del model_params['predictions_test_last']
    if 'targets_test_last' in model_params:
        del model_params['targets_test_last']
    # if 'All_Iterations' in model_params:
    #     del model_params['All_Iterations']
    if 'all_loss_train_set' in model_params:
        del model_params['all_loss_train_set']
    if 'all_loss_val_set' in model_params:
        del model_params['all_loss_val_set']
    if 'all_loss_test_set' in model_params:
        del model_params['all_loss_test_set']
    if 'all_loss_test_set_last' in model_params:
        del model_params['all_loss_test_set_last']
    if 'all_loss_test_set_best' in model_params:
        del model_params['all_loss_test_set_best']
    if 'all_metrics_train_force' in model_params:
        del model_params['all_metrics_train_force']
    if 'all_metrics_val_force' in model_params:
        del model_params['all_metrics_val_force']
    if 'all_metrics_test_force' in model_params:
        del model_params['all_metrics_test_force']
    if 'metrics_val_force_best' in model_params:
        del model_params['metrics_val_force_best']
    if 'all_metrics_test_force_last' in model_params:
        del model_params['all_metrics_test_force_last']
    if 'all_metrics_test_force_best' in model_params:
        del model_params['all_metrics_test_force_best']

    return model_params


def standardize_fun(data, epsilon=0.00001):
    m = data.mean()
    s = data.std()
    data -= m
    data /= (s+epsilon)
    return data
