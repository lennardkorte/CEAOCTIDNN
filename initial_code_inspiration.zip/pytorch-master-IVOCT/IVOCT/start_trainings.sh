#!/bin/bash
source /home/Mieling/pytorchLocal/venv/bin/activate
#cd /home/Mieling/pytorchLocal/pytorch/

python -m train mtec test_cfg gpu00 ""
#python -m train mtec splitFOV.splitFOV_2path_3D_LPandRP_Gel_10_P_All gpu00 ""
#python -m train mtec splitFOV.splitFOV_5path_4D_LP_Gel_10_P_All gpu00 ""

