# -*- coding: utf-8 -*-
import sys
import torch
import torch.nn as nn
import torch.optim as optim
# from torch.optim import lr_scheduler
# import torch.nn.functional as F
# import torchvision
# from torchvision import datasets, models as tv_models
# from torch.utils.data import DataLoader
# from torchsummary import summary
# from scipy import io
# import threading
# import math
# import gc
# import copy
# import psutil
# import visdom
# import sklearn.preprocessing
# from sklearn.utils import class_weight
# from sklearn.metrics import confusion_matrix, auc, roc_curve, f1_score, roc_auc_score
import numpy as np
import pickle
from pathlib import Path
import os
from glob import glob
import re
import importlib
import time
import wandb
import scipy.io as sio
import random
import IVOCT.models as models
import IVOCT.utils as utils
import IVOCT.data_loaders as data_loaders


def main():
    # add configuration file
    # Dictionary for model configuration
    cfg = {}
    # torch.backends.cudnn.enabled = False
    torch.backends.cudnn.benchmark = True

    # sys.argv = [sys.argv[0], 'mtec', 'test_cfg', 'gou00', '']
    # Import machine config
    pc_cfg = importlib.import_module('IVOCT.pc_cfgs.' + sys.argv[1])
    cfg.update(pc_cfg.cfg)

    # Import model config
    print(cfg['base_path'])
    model_cfg = importlib.import_module('IVOCT.cfgs.' + sys.argv[2])
    cfg_model = model_cfg.init(cfg)
    cfg.update(cfg_model)

    if len(sys.argv) > 1:
        # Set visible devices
        if 'gpu' in sys.argv[3]:
            cfg['numGPUs'] = [int(s) for s in re.findall(r'\d+', sys.argv[3])]
            cuda_str = ""
            for i in range(len(cfg['numGPUs'])):
                cuda_str = cuda_str + str(cfg['numGPUs'][i])
                if i is not len(cfg['numGPUs']) - 1:
                    cuda_str = cuda_str + ","
            print("Devices to use:", cuda_str)
            os.environ["CUDA_VISIBLE_DEVICES"] = cuda_str

        # use deterministic training?
    if cfg.get('determ_train', False):
        torch.manual_seed(18)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        if cfg.get('determ_batching', False):
            np.random.seed(18)
            random.seed(18)

    # Indicate training
    # cfg['trainSetState'] = 'train'  # not used

    # Save dictonary
    saveDict = {}  # dictonary for the final test result

    # Create basepath if it doesnt exist yet
    cfg['Save_Name'] = str(sys.argv[2]) + '_' + str(sys.argv[4])
    cfg['save_path'] = cfg['save_path'] + cfg['experiment_folder'] + cfg['Save_Name']
    if not os.path.isdir(cfg['save_path']):
        os.makedirs(cfg['save_path'])  ## create folder for entire Model and all folds
    cfg['save_path'] = cfg['save_path'] + '/'

    # Set configs for HPC usage
    if 'hpc_local' in sys.argv[1]:
        print('Preloading is used for HPC Cluster')
        cfg['preload'] = False
    else:
        print('Use MTEC Cluster')
        cfg.get('preload', False)

    # Take care of CV
    for cv in range(cfg['numCV']):
        # check if Crossfold is already partly trained
        load_old = 0
        path_last = Path(cfg['save_path'] + cfg['Save_Name'] + '_CV_end' + str(cv) + '.pkl')
        prevFile = Path(cfg['save_path'] + cfg['Save_Name'] + '_CV_' + str(cv) + '.pkl')
        if path_last.exists():
            print("CV already Trained")
            with open(cfg['save_path'] + cfg['Save_Name'] + '_CV_end_save' + str(cv) + '.pkl', 'rb') as f:
                saveDict = pickle.load(f)  # load save dict
            continue
        elif prevFile.exists():
            print("Part of CV already done")
            load_old = 1
            with open(cfg['save_path'] + cfg['Save_Name'] + '_CV_' + str(cv) + '.pkl', 'rb') as f:
                cfg = pickle.load(f)  # load cfg
                # update with current cfg
                model_cfg = importlib.import_module('IVOCT.cfgs.' + sys.argv[2])
                cfg_model = model_cfg.init(cfg)
                cfg.update(cfg_model)
                # cfg['training_steps']  = 4000

                print('load params')
        else:
            print('Train CV...')
            cfg['Best_Epoch'] = 0
            cfg['all_loss_val_set'] = []
            cfg['all_loss_train_set'] = []
            # cfg['All_Iterations'] = []
            cfg['all_metrics_val'] = []
            cfg['all_metrics_train'] = []
            # cfg['Loss_Val_Set_Prev'] = 1000000
            # Track metrics for saving best model
            cfg['val_best'] = 0.0
            cfg['wandb_id'] = wandb.util.generate_id()

            cfg['saveDir'] = cfg['save_path'] + 'cv_' + str(cv)
            if not os.path.isdir(cfg['saveDir']):
                os.mkdir(cfg['saveDir'])  # create folder for Crossfold

        # Init wandb project for current fold (cv)
        # update
        wandb.init(project="IVOCT", group=str(sys.argv[2]) + '_' + str(sys.argv[4]), id=cfg['wandb_id'],
                   resume="allow", name=str(sys.argv[2]) + '_' + str(sys.argv[4]) + '_' + str(cv), reinit=True,
                   dir=os.getenv("WANDB_DIR", '/tmp/Mieling/'))

        # Reduce for Weights and biases
        model_params = utils.wandb_reduce_dict(cfg, cv)
        wandb.config.update(model_params, allow_val_change=True)  # update the wandb config,

        # Reset model graph
        # importlib.reload(models)
        # Collect model variables
        modelVars = {}
        modelVars['device'] = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        print(modelVars['device'])
        # Scaler for mixep precision training
        modelVars['scaler'] = torch.cuda.amp.GradScaler()
        # get data loaders
        import warnings
        warnings.warn("watchout")
        cfg, modelVars = data_loaders.return_ivoct_data_loaders(cfg, modelVars, cv)

        # Models
        modelVars['model'] = models.get_model(cfg)

        # multi gpu support
        if len(cfg['numGPUs']) > 1:
            modelVars['model'] = nn.DataParallel(modelVars['model'])
        modelVars['model'] = modelVars['model'].to(modelVars['device'])

        # Loss
        if cfg.get('Loss_Function', 'MSE') == 'MSE':
            modelVars['criterion'] = nn.MSELoss()
        elif cfg.get('Loss_Function', 'MSE') == 'SmoothL1Loss':
            modelVars['criterion'] = nn.SmoothL1Loss()
        elif cfg.get('Loss_Function', 'MSE') == 'cross_entropy':
            modelVars['criterion'] = nn.CrossEntropyLoss(weight=cfg['class_weights'].to(modelVars['device']))
        else:
            modelVars['criterion'] = nn.L1Loss()

        pytorch_total_params = sum(p.numel() for p in modelVars['model'].parameters() if p.requires_grad)
        print('Number of Training Parameters', pytorch_total_params)

        if cfg.get('optimizer', 'Adam') == 'Adam':
            modelVars['optimizer'] = optim.Adam(modelVars['model'].parameters(), lr=cfg['learning_rate'])
        elif cfg.get('optimizer', 'Adam') == 'AdamW':
            modelVars['optimizer'] = optim.AdamW(modelVars['model'].parameters(), lr=cfg['learning_rate'])
        elif cfg.get('optimizer', 'Adam') == 'SGD':
            modelVars['optimizer'] = optim.SGD(modelVars['model'].parameters(), lr=cfg['learning_rate'], momentum=0.9)

        # # Try to find appropriate LR values
        # if cfg.get('reinit_lr_with_finder', False):
        #     lr_min, lr_max = lr_finder.find_lr(cfg, modelVars)
        #     cfg['max_lr'] = lr_max
        #     for g in modelVars['optimizer'].param_groups:
        #         g['lr'] = lr_min
        # modelVars['scheduler'] = lr_scheduler.OneCycleLR(modelVars['optimizer'], max_lr=cfg['max_lr'],
        #                                                  steps_per_epoch=len(modelVars['dataloader_trainInd']),
        #                                                  epochs=cfg['training_steps'])
        # # Decay LR by a factor of 0.1 every 7 epochs
        # modelVars['scheduler'] = lr_scheduler.StepLR(modelVars['optimizer'], step_size=cfg['lowerLRAfter'],
        #                                              gamma=1 / np.float32(cfg['LRstep']))

        # Set up training
        # loading from checkpoint
        if load_old:
            # Find last, not last best checkpoint
            files = glob(cfg['saveDir'] + '/*')
            global_steps = np.zeros([len(files)])
            for i in range(len(files)):
                # Use meta files to find the highest index
                if 'best' in files[i]:
                    continue
                if 'checkpoint_' not in files[i]:
                    continue
                    # Extract global step
                nums = [int(s) for s in re.findall(r'\d+', files[i])]
                global_steps[i] = nums[-1]
            # Create path with maximum global step found
            chkPath = cfg['saveDir'] + '/checkpoint_' + str(int(np.max(global_steps))) + '.pt'
            print("Restoring: ", chkPath)  # restore Model with maximum number of iterations!
            # Load
            state = torch.load(chkPath)  # load previous model with states
            # Initialize model and optimizer
            state = utils.remove_module_from_state(state)  # remove modules from state
            # Initialize model and optimizer
            if isinstance(modelVars['model'], nn.DataParallel):
                modelVars['model'].module.load_state_dict(state['state_dict'])
            else:
                modelVars['model'].load_state_dict(state['state_dict'])

            modelVars['optimizer'].load_state_dict(state['optimizer'])
            # state['scheduler']['_step_count'] = state['scheduler']['_step_count']-len(modelVars['dataloader_trainInd'])
            # modelVars['scheduler'].load_state_dict(state['scheduler'])
            modelVars['scaler'].load_state_dict(state['scaler'])
            start_epoch = state['epoch'] + 1
            cfg['last_best_ind'] = int(np.max(global_steps))
        else:
            start_epoch = 1
            cfg['last_best_ind'] = -1

        # Num batches
        numBatchesTrain = int(len(modelVars['dataloader_trainInd']))  # how many iterations for one epoch
        print("Train batches", numBatchesTrain)

        # #############################  Run training ###############################
        start_time = time.time()

        pytorch_total_params = sum(p.numel() for p in modelVars['model'].parameters() if p.requires_grad)
        print('Number of Training Parameters', pytorch_total_params)
        wandb.log({'pytorch_total_params': pytorch_total_params})

        # Early stopping
        early_stop = False
        cfg['ES_counter'] = 0
        # wandb.watch(modelVars['model'])
        # used for validation printing (work around)
        val_print = False
        print("Start Training...")
        for step in range(start_epoch, cfg['training_steps'] + 1):  # tranings_steps = number of epochs, step = epoch
            if early_stop:
                break
            start_it_epoch = time.time()
            modelVars['model'].train()
            for j, (inputs, labels) in enumerate(modelVars['dataloader_trainInd']):

                # start_it = time.time()
                inputs = inputs.to(modelVars['device'])
                labels = labels.squeeze().type(torch.LongTensor).to(modelVars['device'])
                # stack labels here
                # zero the parameter gradients
                modelVars['optimizer'].zero_grad()
                # forward
                # track history if only in train
                with torch.set_grad_enabled(True):
                    with torch.cuda.amp.autocast():
                        outputs = modelVars['model'](inputs)
                        loss = modelVars['criterion'](outputs, labels)
                    # backward + optimize only if in training phase
                    # One Epoch of training
                    modelVars['scaler'].scale(loss).backward()
                    modelVars['scaler'].step(modelVars['optimizer'])
                    # modelVars['scheduler'].step()
                    # Update mixed precision scaler
                    modelVars['scaler'].update()
                wandb.log({'loss training': loss})
                wandb.log({'learning rate': modelVars['optimizer'].param_groups[0]['lr']})
                # print('Iteration: ', j)

            duration_e = time.time() - start_it_epoch
            print('duration for one epoch', duration_e)
            loss_train = loss.cpu().detach().numpy()
            # Plot Losses Online
            cfg['all_loss_train_set'].append(loss_train)

            if step % cfg['display_step'] == 0:  # show all display_steps = 1, current state of the traninig
                print('Eval:')
                duration = time.time() - start_time
                # Calculate evaluation metrics
                # Adjust model state
                modelVars['model'].eval()

                # Get metrics =  [acc, sensitivity, specificity, conf, f1, roc_auc, wacc]
                loss_val, metrics_val, pred_val, label_val = utils.get_classification_eval(cfg, 'valInd', modelVars)
                print('Metrics Accuracy: ', metrics_val[0])
                cfg['all_metrics_val'].append(metrics_val)
                cfg['all_loss_val_set'].append(loss_val)
                wandb.log({'Loss Validation Set': loss_val})
                # wandb.log({'Metrics Validation Set': metrics_val})
                wandb.log({'Val Accuracy': metrics_val[0]})
                wandb.log({'Val sensitivity': metrics_val[1]})
                wandb.log({'Val specificity': metrics_val[2]})
                wandb.log({'Val F1': metrics_val[4]})
                wandb.log({"conf_mat_val": wandb.plot.confusion_matrix(y_true=label_val, preds=np.argmax(pred_val, 1),
                                               class_names=cfg['class_labels'], title="Val Confusion Matrix")})
                # etc. or pass dict

                eval_metric = metrics_val[0]

                if cfg['print_trainerr']:
                    loss_tr, metrics_train, _, _ = utils.get_classification_eval(cfg, 'trainInd_eval', modelVars)
                    cfg['all_metrics_train'].append(metrics_train)
                    # wandb.log({'Metrics Train Set': metrics_train})
                    wandb.log({'Train Accuracy': metrics_train[0]})
                    wandb.log({'Train sensitivity': metrics_train[1]})
                    wandb.log({'Train specificity': metrics_train[2]})
                    wandb.log({'Loss': loss_tr})
                else:
                    metrics_train = 0
                    loss_tr = 0.00000000000001

                # Check if we have a new best value
                # Early stopping
                # prevent overfitting on validation set with val los <= tr los
                if eval_metric >= cfg['val_best'] and metrics_val[0] <= metrics_train[0]:
                    # reset early stopping counter
                    cfg['ES_counter'] = 0
                    # print trajectories online
                    oldBestInd = cfg['last_best_ind']
                    cfg['val_best'] = eval_metric
                    cfg['last_best_ind'] = step
                    cfg['metrics_val_best'] = metrics_val
                    wandb.log({'b-Loss Validation Set': loss_val})
                    # wandb.log({'b-Metrics Validation Set': metrics_val})
                    wandb.log({'b-Val Accuracy': metrics_val[0]})
                    wandb.log({'b-Val sensitivity': metrics_val[1]})
                    wandb.log({'b-Val specificity': metrics_val[2]})
                    wandb.log({'b-Val Epoch': step})
                    wandb.log({'b-Val F1': metrics_val[4]})
                    wandb.log({"conf_mat_b_val": wandb.plot.confusion_matrix(y_true=label_val,
                                                                             preds=np.argmax(pred_val, 1),
                                                                             class_names=cfg['class_labels'],
                                                                             title="b-Val Confusion Matrix")})
                    val_print = True

                    # Delete previously best model
                    if os.path.isfile(cfg['saveDir'] + '/checkpoint_best_' + str(oldBestInd) + '.pt'):
                        os.remove(cfg['saveDir'] + '/checkpoint_best_' + str(oldBestInd) + '.pt')
                    # Save currently best model
                    state = {'epoch': step, 'state_dict': modelVars['model'].state_dict(),
                             'optimizer': modelVars['optimizer'].state_dict(),
                             # 'scheduler': modelVars['scheduler'].state_dict(),
                             'scaler': modelVars['scaler'].state_dict()}
                    torch.save(state, cfg['saveDir'] + '/checkpoint_best_' + str(step) + '.pt')

                    if cfg.get('peak_at_testerr', False):
                        loss_test, metrics_test, predictions_test_best, targets_test_best = utils.get_classification_eval(
                            cfg, 'testInd', modelVars)
                        # cfg['Predictions_TestSet'] = predictions_test_best # Predictions
                        # cfg['Targets_TestSet'] = targets_test_best # store to have everything in one file
                        cfg['all_metrics_test'] = metrics_test
                        cfg['all_loss_test_set'] = loss_test
                        # wandb.log({'b-Loss test Set': loss_test})
                        # wandb.log({'b-Metrics test Set': metrics_test})
                        wandb.log({'b-test Accuracy': metrics_test[0]})
                        wandb.log({'b-test sensitivity': metrics_test[1]})
                        wandb.log({'b-test specificity': metrics_test[2]})
                        wandb.log({'b-test F1': metrics_test[4]})
                else:
                    # add early stopping counter
                    cfg['ES_counter'] += 1

                if cfg.get('ES_patience', 0):
                    if cfg['ES_counter'] >= cfg['ES_patience'] / cfg['display_step']:
                        early_stop = True

                # save current Model and Metrics
                cfg['lastlast_ind'] = step
                # Save current model
                state = {'epoch': step, 'state_dict': modelVars['model'].state_dict(),
                         'optimizer': modelVars['optimizer'].state_dict(),
                         # 'scheduler': modelVars['scheduler'].state_dict(),
                         'scaler': modelVars['scaler'].state_dict()}
                torch.save(state, cfg['saveDir'] + '/checkpoint_' + str(step) + '.pt')
                # Delete last one
                if step == cfg['display_step']:
                    lastInd = 1
                else:
                    lastInd = step - cfg['display_step']
                if os.path.isfile(cfg['saveDir'] + '/checkpoint_' + str(lastInd) + '.pt'):
                    os.remove(cfg['saveDir'] + '/checkpoint_' + str(lastInd) + '.pt')
                    # Save mdlParameters for current
                with open(cfg['save_path'] + cfg['Save_Name'] + "_CV_" + str(cv) + '.pkl', 'wb') as f:
                    pickle.dump(cfg, f, pickle.HIGHEST_PROTOCOL)

                # ################################# Print #######################################
                # metrics = [acc, sensitivity, specificity, conf, f1, roc_auc, wacc]
                np.set_printoptions(precision=4)
                print("\n")
                print('Model Name: ' + sys.argv[2])
                print('Fold: %d/%d Iteration: %d/%d (%d h %d m %d s)' % (
                    cv+1, cfg['numCV'], step, cfg['training_steps'], int(duration / 3600),
                    int(np.mod(duration, 3600) / 60), int(np.mod(np.mod(duration, 3600), 60))) + time.strftime(
                    "%d.%m.-%H:%M:%S", time.localtime()))
                if val_print:
                    print("Loss on ", 'ValInd', "set: ", loss_val, " (best Accuracy: ", cfg['metrics_val_best'][0],
                          " at Epoch ", cfg['last_best_ind'], ")")
                print('Current Validation Performance')
                print("Accuracy", metrics_val[0])
                print("sensitivity", metrics_val[1])
                print("specificity: ", metrics_val[2])
                print("F1: ", metrics_val[4])

                if cfg.get('peak_at_testerr', False) and val_print:
                    if eval_metric <= cfg['val_best']:
                        print('-------------------<Test>--------------------------')
                        print("Best Test loss: ", loss_test)
                        print("Test Accuracy: ", metrics_test[0], "Test sensitivity: ",
                              metrics_test[1], " Test specificity: ", metrics_test[2])

                print('-------------------<Train>-------------------------')
                # Potentially print train err
                if cfg['print_trainerr']:
                    print("Train loss: ", loss_tr, " Accuracy: ", metrics_train[0], " sensitivity: ", metrics_train[1],
                          " specificity: ", metrics_train[2], " F1: ", metrics_train[4])

        # Save Metrics
        sio.savemat(cfg['save_path'] + cfg['Save_Name'] + "_CV_" + str(cv) + ".mat", cfg)
        # Save Last Model
        state = {'epoch': step, 'state_dict': modelVars['model'].state_dict(),
                 'optimizer': modelVars['optimizer'].state_dict(),
                 # 'scheduler': modelVars['scheduler'].state_dict(),
                 'scaler': modelVars['scaler'].state_dict()}
        torch.save(state, cfg['saveDir'] + '/checkpoint_' + str(step) + '.pt')

        # Evalute on Test-Set with Last Model
        if cfg.get('use_test_set', False):
            modelVars['model'].eval()

            print('Check with Last Model on Test-Set:')
            loss_test_last, metrics_test_last, pred_test_last, targets_test_last = utils.get_classification_eval(
                cfg, 'testInd', modelVars)
            print('Loss:', loss_test_last)
            print('Metrics Accuracy: ', metrics_test_last[0])

            cfg['all_metrics_test_last'] = metrics_test_last
            cfg['all_loss_test_set_last'] = loss_test_last
            cfg['pred_test_last'] = pred_test_last  # Predictions
            cfg['targets_test_last'] = targets_test_last  # store to have everything in one file

            wandb.log({'Test Accuracy (Last)': metrics_test_last[0]})
            wandb.log({'Test sensitivity (Last)': metrics_test_last[1]})
            wandb.log({'Test specificity (Last)': metrics_test_last[2]})
            wandb.log({'Test F1 (Last)': metrics_test_last[4]})
            wandb.log({"conf_mat_test_last": wandb.plot.confusion_matrix(y_true=targets_test_last,
                                                                     preds=np.argmax(pred_test_last, 1),
                                                                     class_names=cfg['class_labels'],
                                                                     title="Test (Last) Confusion Matrix")})

            print('Check with Best Model based on Val set - Test-Set:')
            model_paths = glob(cfg['saveDir'] + '/*.pt')
            best_model_found = False
            for mdl_path in model_paths:
                if 'best' in mdl_path:
                    best_model_found = True
                    print("Restoring best Model: ", mdl_path)  # restore best Model based on Validation Set
                    # Load
                    state = torch.load(mdl_path)  # load previous model with states
                    # modelVars['model'].load_state_dict(state['state_dict'])
                    # Initialize model and optimizer
                    state = utils.remove_module_from_state(state)  # remove modules from state
                    # Initialize model and optimizer
                    if isinstance(modelVars['model'], nn.DataParallel):
                        modelVars['model'].module.load_state_dict(state['state_dict'])
                    else:
                        modelVars['model'].load_state_dict(state['state_dict'])

                    loss_test_best, metrics_test_best, predictions_test_best, targets_test_best \
                        = utils.get_classification_eval(cfg, 'testInd', modelVars)
                    break

            if not best_model_found:
                print('No Best Model during Training (Take Last Model Instead)')
                loss_test_best = loss_test_last
                metrics_test_best = metrics_test_last
                predictions_test_best = pred_test_last
                targets_test_best = targets_test_last


            print("Metrics on Testset (Best Val Model) {}".format(metrics_test_best))
            print('-------------------------------------------')
            cfg['predictions_test_best'] = predictions_test_best
            cfg['targets_test_best'] = targets_test_best
            cfg['all_metrics_test_best'] = metrics_test_best
            cfg['all_loss_test_set_best'] = loss_test_best

            wandb.log({'Test Accuracy (Best)': metrics_test_best[0]})
            wandb.log({'Test sensitivity (Best)': metrics_test_best[1]})
            wandb.log({'Test specificity (Best)': metrics_test_best[2]})
            wandb.log({'Test F1 (Best)': metrics_test_best[4]})
            wandb.log({"conf_mat_test_best": wandb.plot.confusion_matrix(y_true=targets_test_best,
                                                                         preds=np.argmax(predictions_test_best, 1),
                                                                         class_names=cfg['class_labels'],
                                                                         title="Test (Best) Confusion Matrix")})
        if cv == 0:
            saveDict['targets_all'] = cfg['targets_test_best']
            saveDict['predictions_all'] = cfg['predictions_test_best']
        else:
            saveDict['targets_all'] = np.concatenate((saveDict['targets_all'], np.array(cfg['targets_test_best'])))
            saveDict['predictions_all'] = np.concatenate(
                (saveDict['predictions_all'], np.array(cfg['predictions_test_best'])))

        # Save Setting for current Fold
        with open(cfg['save_path'] + cfg['Save_Name'] + "_CV_end" + str(cv) + '.pkl', 'wb') as f:
            pickle.dump(cfg, f, pickle.HIGHEST_PROTOCOL)
            # Save Final cfg
        # sio.savemat(cfg['save_path']  + cfg['Save_Name']+ "_CV_"+ str(cv) +".mat",cfg)
        # Save Targets and Predictions
        with open(cfg['save_path'] + cfg['Save_Name'] + "_CV_end_save" + str(cv) + '.pkl', 'wb') as f:
            pickle.dump(saveDict, f, pickle.HIGHEST_PROTOCOL)
            # # stack and save predictions for the trained folds
            # sio.savemat(cfg['save_path']  + cfg['Save_Name']+ "_all_folds_predictions" +".mat", saveDict)

        if cv == cfg['numCV'] - 1:
            print('Training is done......')
            sio.savemat(cfg['save_path'] + cfg['Save_Name'] + "_all_folds" + ".mat", saveDict)
            with open(cfg['save_path'] + cfg['Save_Name'] + '_all_folds' + '.pkl', 'wb') as f:
                pickle.dump(saveDict, f, pickle.HIGHEST_PROTOCOL)
            print('Final Logging file saved!')
        else:
            print('Next Fold......')
            # Free everything in modelvars
            modelVars.clear()

        # Free everything in modelvars
        modelVars.clear()


if __name__ == '__main__':
    main()
