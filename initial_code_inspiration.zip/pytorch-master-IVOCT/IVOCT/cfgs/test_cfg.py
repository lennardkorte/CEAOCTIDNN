# -*- coding: utf-8 -*-
import sys
import os
import h5py
import re
import csv
import numpy as np
# from glob import glob
# import scipy
# import pickle
import warnings
from natsort import natsorted
from pathlib import Path
import torch
from sklearn.utils.class_weight import compute_class_weight


def init(cfg):
    # cfg = {}
    # Number of GPUs on device
    cfg['numGPUs'] = [0]

    # ### Model Selection ###
    # 'EfficientNetB6', 'ResNet18', SENet, AlexNet', DenseNet121, ResNext50, WideResNet50
    cfg['model_type'] = 'ResNet18'
    cfg['pretrained'] = False
    cfg['numOut'] = 2  # number of output classes, could also be 1 for binary

    # ########################### Select Data  ###########################
    # 3D_MS = Mean + Std in channel
    # cfg['Data_Type'] = '3D_T'
    # directory to the data
    cfg['experiment_folder'] = 'ivoct2/ivoct_both/'  # ivoct_both_c3/
    cfg['label_folder'] = 'labelsbin/'
    cfg['input_type'] = 'orig/'
    cfg['dataDir'] = cfg['base_path'] + cfg['experiment_folder'] + cfg['input_type']  # change your data path here
    cfg['dataset_name'] = 'raw'
    cfg['labelset_name'] = 'targets'

    cfg['data_augmetation'] = False
    # if data_augmentation true then:
    cfg['temporal_skip'] = False  # randomly skip every 2nd
    cfg['temporal_reverse'] = False
    cfg['flip_data'] = False
    cfg['transpose_data'] = False
    cfg['elastic_transform'] = False

    # # Input size
    # cfg['input_size'] = [300, 300]

    # ### Training Parameters ###
    # Training loss
    cfg['Loss_Function'] = 'cross_entropy'
    cfg['optimizer'] = 'Adam'
    # Batch size
    cfg['batchSize'] = 128
    cfg['batchSize_eval'] = cfg['batchSize']
    cfg['training_steps'] = 250  # number of epochs
    cfg['ES_patience'] = 0  # early stopping after epochs without improvement, 0 if no ES
    # Preload
    cfg['preload'] = True
    # learning rate
    cfg['learning_rate'] = 1e-4
    # LR Scheduler: OnecycleLR

    # Display error every X steps
    cfg['display_step'] = 1  # nach wie viel epochs show val performance / train performance

    # Print trainerr
    cfg['print_trainerr'] = True
    cfg['use_test_set'] = True  # eval model on test set
    # Subtract trainset mean?
    # Data normalization / Input norm -> Data Loader
    cfg['mean_std_normalize'] = True
    cfg['mean_std_normalize_fixed'] = False
    cfg['zero_one_normalize'] = False

    # Get file Paths
    # all data path
    cfg['data_paths'] = []
    # r=root, d=directories, f = files
    for r, d, f in os.walk(cfg['dataDir']):
        for file in f:
            if '.h5' in file:
                cfg['data_paths'].append(os.path.join(r, file))

    # get set paths
    level_up_path = []
    for path in cfg['data_paths']:
        path_upper = str(Path(path).parents[0])
        if path_upper not in level_up_path:
            level_up_path.append(path_upper)
    level_up_path = [s + '/' for s in level_up_path]

    # set up list such that we have [[0.h5,1.h5],[.....]] for the indivdual trajectories (e.g. 75)
    all_files_path = []
    for path_t in level_up_path:
        files_trajectory = []
        for path in cfg['data_paths']:
            if path_t in path:
                files_trajectory.append(path)
        new = natsorted(files_trajectory)
        all_files_path = all_files_path + new  # add the sequence sorted

    cfg['all_files_path'] = all_files_path

    # ######################### Set Index for Train, Test, Val ##########################
    # Set up Train and Validation Index

    # Set Index for Folds
    cfg['numCV'] = 1
    cfg['trainIndCV'] = []
    cfg['valIndCV'] = []
    cfg['testIndCV'] = []

    # set up the different indices
    cfg['valInd'] = []
    cfg['testInd'] = []
    cfg['trainInd'] = []
    # cfg['trainInd_eval'] = []

    # rand
    all_sets = ['set1/', 'set2/', 'set3/', 'set4/', 'set5/', 'set6/', 'set10/', 'set14/', 'set15/', 'set17/', 'set20/',
                'set23/', 'set24/', 'set25/', 'set26/', 'set28/', 'set29/', 'set30/', 'set32/', 'set33/', 'set35/',
                'set37/', 'set38/', 'set39/', 'set40/', 'set42/', 'set43/', 'set44/', 'set45/', 'set47/', 'set48/',
                'set50/', 'set52/', 'set54/', 'set55/', 'set57/', 'set59/', 'set61/', 'set62/', 'set63/', 'set64/',
                'set65/', 'set68/', 'set69/', 'set70/', 'set72/', 'set74/', 'set75/', 'set76/']
    # all_sets = ['set%d' % i for i in range(1, 77)]
    warnings.warn("Define splits here")
    valset_markers = []  # ['set1/', 'set50/', etc.]
    testset_markers = []
    trainset_markers = [s for s in all_sets if s not in valset_markers + testset_markers]
    # separate file indices into sets
    for i, path in enumerate(cfg['all_files_path']):
        if any(marker in path for marker in testset_markers):
            cfg['testInd'] = np.concatenate((cfg['testInd'], np.array([i])))
        elif any(marker in path for marker in valset_markers):
            cfg['valInd'] = np.concatenate((cfg['valInd'], np.array([i])))
        elif any(marker in path for marker in trainset_markers):
            cfg['trainInd'] = np.concatenate((cfg['trainInd'], np.array([i])))
        else:
            path_str = path.partition(cfg['dataDir'])[-1]
            print(f'File {path_str} not in any dataset but also not excluded from all files')

    print('Validation (number of different trajectories)', len(cfg['valInd']))
    print('Test (number of different trajectories)', len(cfg['testInd']))
    print('Train (number of different trajectories)', len(cfg['trainInd']))

    cfg['valIndCV'].append(np.array(cfg['valInd']))  # save the current Validation indices
    cfg['testIndCV'].append(np.array(cfg['testInd']))  # save the current Validation indices
    cfg['trainIndCV'].append(np.array(cfg['trainInd']))  # set up the corresponding train set
    cfg['trainInd_evalCV'] = cfg['trainIndCV']

    # ######################## Set Up Labels for Data Set ##########################
    label_paths = [path.replace('/orig/', '/' + cfg['label_folder']).replace('/im_', '/t_').replace('ims/', 'tars/')
                   for path in cfg['all_files_path']]
    label_data = [int(h5py.File(path, 'r')[cfg['labelset_name']][0]) for path in label_paths]

    # reassign labels 1,2,6 etc. to ind
    if 'bin' in cfg['label_folder']:
        cfg['class_labels'] = ['No Plaque', 'Plaque']
    elif '_c3' in cfg['experiment_folder']:
        label_c3_dict = {6: 0, 1: 1, 2: 2}
        label_data = [label_c3_dict[t] for t in label_data]
        cfg['class_labels'] = ['No Plaque', 'Calcified Plaque', 'Lipid/fibrous Plaque']

    # convert
    cfg['data_labels'] = np.asarray(label_data)
    # classes, counts = np.unique(cfg['data_labels'], return_counts=True)
    class_weights = compute_class_weight(class_weight='balanced',
                                         classes=np.unique(cfg['data_labels']),
                                         y=cfg['data_labels'])
    cfg['class_weights'] = torch.tensor(class_weights, dtype=torch.float)

    # Ind properties
    print("Train")
    for i in range(len(cfg['trainIndCV'])):
        print(cfg['trainIndCV'][i].shape)
    print("Val")
    for i in range(len(cfg['valIndCV'])):
        print(cfg['valIndCV'][i].shape)
        print("Intersect", np.intersect1d(cfg['trainIndCV'][i], cfg['valIndCV'][i]))
    print("test")
    for i in range(len(cfg['testIndCV'])):
        print(cfg['testIndCV'][i].shape)
    print("Intersect", np.intersect1d(cfg['trainIndCV'][i], cfg['testIndCV'][i]))

    return cfg
