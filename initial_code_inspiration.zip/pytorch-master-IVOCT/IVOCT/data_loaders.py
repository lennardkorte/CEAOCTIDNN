# -*- coding: utf-8 -*-
import warnings
import psutil
from torch.utils.data import DataLoader
import numpy as np
import IVOCT.utils as utils
import torchvision
import torchvision.transforms as transforms
import torch


def return_ivoct_data_loaders(cfg, modelVars, cv):
    # Data Sets
    dataset_train = []
    dataset_val = []
    dataset_test = []

    # load index for CV
    cfg['trainInd'] = cfg['trainIndCV'][cv]  # overwrite for current fold
    cfg['valInd'] = cfg['valIndCV'][cv]  # overwrite for current fold
    cfg['testInd'] = cfg['testIndCV'][cv]  # overwrite for current fold
    cfg['trainInd_eval'] = cfg['trainInd_evalCV'][cv]
    cfg['trainInd_eval'] = cfg['trainInd_eval'][::2]
    if cfg.get('full_training_eval', False):
        cfg['trainInd_eval'] = cfg['trainInd']

    print('Number of Training Examples: ', len(cfg['trainInd']))
    print('Model:', cfg['Save_Name'])
    print('Fold:', cv)
    print('Number of Training Examples: ', len(cfg['trainInd']))
    print('Number of Training Examples for evaluation: ', len(cfg['trainInd_eval']))
    print('Number of Val Examples: ', len(cfg['valInd']))
    print('Number of Test Examples: ', len(cfg['testInd']))

    # Set up dataloaders
    # For train
    # num_workers = psutil.cpu_count(logical=False)
    num_workers = 4  # 14
    # warnings.warn("Currently num_workers chosen as 0")
    dataset_train = utils.IVOCT_Dataset(cfg, 'trainInd')  # loader for traningset (String indicates train or val set)
    # Training Data Loader
    modelVars['dataloader_trainInd'] = DataLoader(dataset_train, batch_size=cfg['batchSize'], shuffle=True,
                                                  num_workers=num_workers, pin_memory=True, drop_last=True)
    # For train Evaluation during training
    dataset_train_eval = utils.IVOCT_Dataset(cfg, 'trainInd_eval')  # loader for val set #valInd
    modelVars['dataloader_trainInd_eval'] = DataLoader(dataset_train_eval, batch_size=cfg['batchSize_eval'],
                                                       shuffle=False, num_workers=num_workers, pin_memory=True)
    # For val
    dataset_val = utils.IVOCT_Dataset(cfg, 'valInd')  # loader for val set #valInd
    modelVars['dataloader_valInd'] = DataLoader(dataset_val, batch_size=cfg['batchSize_eval'], shuffle=False,
                                                num_workers=num_workers, pin_memory=True)
    # For Testing  
    if cfg.get('use_test_set', False):
        dataset_test = utils.IVOCT_Dataset(cfg, 'testInd')  # loader for val set #valInd
        modelVars['dataloader_testInd'] = DataLoader(dataset_test, batch_size=cfg['batchSize_eval'], shuffle=False,
                                                     num_workers=num_workers, pin_memory=True)

    return cfg, modelVars


# def return_test_data_loaders(cfg, modelVars):
#     batch_size = 20
#
#     transform = transforms.Compose(
#         [transforms.ToTensor(),
#          transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])
#
#     trainset = torchvision.datasets.CIFAR10(root='/home/Mieling/pytorchLocal/data/CIFAR10/', train=True,
#                                             download=True, transform=transform)
#     valid_size = 0.2
#     sampler = torch.utils.data.SubsetRandomSampler
#     num_train = len(trainset)
#     indices = list(range(num_train))
#     np.random.shuffle(indices)
#     split = int(np.floor(valid_size * num_train))
#     train_idx, valid_idx = indices[split:], indices[:split]
#     train_sampler = sampler(train_idx)
#     valid_sampler = sampler(valid_idx)
#
#     modelVars['dataloader_trainInd'] = torch.utils.data.DataLoader(trainset, batch_size=batch_size,
#                                                                    sampler=train_sampler, num_workers=4)
#     modelVars['dataloader_trainInd_eval'] = torch.utils.data.DataLoader(trainset, batch_size=batch_size,
#                                                                         sampler=train_sampler, num_workers=4)
#
#     modelVars['dataloader_valInd'] = torch.utils.data.DataLoader(trainset, batch_size=batch_size,
#                                                                  sampler=valid_sampler, num_workers=4)
#
#     testset = torchvision.datasets.CIFAR10(root='/home/Mieling/pytorchLocal/data/CIFAR10/', train=False,
#                                            download=True, transform=transform)
#
#     modelVars['dataloader_testInd'] = torch.utils.data.DataLoader(testset, batch_size=batch_size,
#                                                                   shuffle=True, num_workers=4)
#
#     cfg['class_labels'] = ['plane', 'car', 'bird', 'cat', 'deer', 'dog', 'frog', 'horse', 'ship', 'truck']
#
#     cfg['class_weights'] = torch.tensor([1, 1, 1, 1, 1, 1, 1, 1, 1, 1], dtype=torch.float)
#
#     return cfg, modelVars
