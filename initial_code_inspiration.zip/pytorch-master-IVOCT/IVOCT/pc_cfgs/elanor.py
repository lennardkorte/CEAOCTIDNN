import os
# Define machine specific paths
cfg = {'base_path': "C:\\Users\\Robin\\Documents\\pytorchLocal\\data\\",
       'save_path': 'C:\\Users\\Robin\\Documents\\pytorchLocal\\logs\\'}
