﻿# import os
# Define machine specific paths
cfg = {'base_path': "/home/Mieling/pytorchLocal/data/",
       'save_path': '/home/Mieling/pytorchLocal/logs/'}
